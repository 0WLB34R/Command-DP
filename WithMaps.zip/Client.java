package WithMaps;

public class Client {
	public static void main(String[] args) {
		Receiver receiver = new Receiver();
		
		ConcreteCommand1 cc1 = new ConcreteCommand1(receiver);
		ConcreteCommand2 cc2 = new ConcreteCommand2(receiver);
		
		Invoker invoker = new Invoker();
		
		invoker.setCommand("c1",cc1);
		invoker.setCommand("c2",cc2);
		
		invoker.runCommand("c1");
		invoker.runCommand("c2");
	}
}
