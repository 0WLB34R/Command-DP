package WithMaps;

import java.util.HashMap;


public class Invoker {
	private HashMap<String,ICommand> commandMap = new HashMap<>();
	//can also be done by hasmaps or individual attributes
	
	public void setCommand(String alias,ICommand command) {
		commandMap.put(alias, command);
	}
	
	public void runCommand(String alias) {
		commandMap.get(alias).execute();
	}
}
