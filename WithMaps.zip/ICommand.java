package WithMaps;

public interface ICommand {
	void execute();
}
