package Car;

public class Acelerar implements ICommand{

	private Auto receiver;
	
	public Acelerar(Auto receiver) {
		this.receiver = receiver;
	}
	@Override
	public void execute() {
		receiver.aumentarVelocidad();
	}

}
