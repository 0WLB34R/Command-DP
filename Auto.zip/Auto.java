package Car;

public class Auto {			//This is the car
	private int speed = 0;
	private String direction = "None";
	
	public void aumentarVelocidad() {
		speed+=10;
		System.out.println("Increasing Speed, Current Speed: "+speed);
	}
	
	public void disminuirVelocidad() {
		speed-=10;
		System.out.println("Decreasing Speed, Current Speed: "+speed);
	}
	
	public void irAdelante() {
		direction = "Forward";
		System.out.println("Current Direction: "+direction);
	}
	
	public void irAtras() {
		direction = "Backward";
		System.out.println("Current Direction: "+direction);
	}
}
