package Car;

public class Desacelerar implements ICommand{

	private Auto receiver;
	
	public Desacelerar(Auto receiver) {
		this.receiver = receiver;
	}
	@Override
	public void execute() {
		receiver.disminuirVelocidad();
	}

}
