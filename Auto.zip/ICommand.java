package Car;

public interface ICommand {
	void execute();
}
