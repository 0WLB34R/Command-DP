package Car;

public class Client {
	public static void main(String[] args) {
		Auto auto = new Auto();
		
		Desacelerar des = new Desacelerar(auto);
		Acelerar ace = new Acelerar(auto);
		Avanzar ava = new Avanzar(auto);
		Retroceder ret = new Retroceder(auto);
		
		Invoker invoker = new Invoker();
		
		invoker.setCommand("Avanzar",ava);
		invoker.setCommand("Retroceder",ret);
		invoker.setCommand("Acelerar",ace);
		invoker.setCommand("Desacelerar",des);
		
		invoker.runCommand("Acelerar");
		invoker.runCommand("Acelerar");
		invoker.runCommand("Avanzar");
		invoker.runCommand("Retroceder");
		invoker.runCommand("Desacelerar");
	}
}
