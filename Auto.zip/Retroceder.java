package Car;

public class Retroceder implements ICommand{

	private Auto receiver;
	
	public Retroceder(Auto receiver) {
		this.receiver = receiver;
	}
	@Override
	public void execute() {
		receiver.irAtras();;
	}

}
