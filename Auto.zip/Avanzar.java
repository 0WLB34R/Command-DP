package Car;

public class Avanzar implements ICommand{

	private Auto receiver;
	
	public Avanzar(Auto receiver) {
		this.receiver = receiver;
	}
	@Override
	public void execute() {
		receiver.irAdelante();
	}

}
