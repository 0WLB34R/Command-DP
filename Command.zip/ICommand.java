
public interface ICommand {
	void execute();
}
