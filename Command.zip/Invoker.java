import java.util.ArrayList;
import java.util.List;

public class Invoker {
	private List<ICommand> commandList = new ArrayList<>();
	//can also be done by hasmaps or individual attributes
	
	public void setCommand(ICommand command) {
		commandList.add(command);
	}
	
	public void runCommand() {
		for(ICommand command : commandList) {
			command.execute();
		}
		commandList.clear();
	}
}
